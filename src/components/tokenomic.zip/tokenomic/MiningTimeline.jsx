// src/components/Tokenomics/MiningTimeline.jsx
import React from "react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts";
import "./MiningTimeline.css";

const miningData = Array.from({ length: 10 }, (_, i) => {
  const year = i + 1;
  const cap = Math.round(90_000_000 * Math.pow(0.9, i)); // 9% y se reduce 10% anual
  return { year: `Year ${year}`, tokens: cap };
});

const MiningTimeline = () => {
  return (
    <div className="mining-timeline-container">
      <h2 className="timeline-title">Annual Mining Cap</h2>
      <ResponsiveContainer width="100%" height={350}>
        <BarChart data={miningData} margin={{ top: 30, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#00f2ff33" />
          <XAxis dataKey="year" stroke="#00f2ffcc" />
          <YAxis stroke="#00f2ffcc" tickFormatter={(v) => `${v / 1_000_000}M`} />
          <Tooltip
            cursor={{ fill: "#00f2ff11" }}
            contentStyle={{ backgroundColor: "#0f0f0faa", borderRadius: 8, border: "1px solid #00f2ff88", color: "#fff" }}
            formatter={(value) => [`${value.toLocaleString()} tokens`, "Cap"]}
          />
          <Bar dataKey="tokens" fill="#00f2ff" radius={[6, 6, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default MiningTimeline;
