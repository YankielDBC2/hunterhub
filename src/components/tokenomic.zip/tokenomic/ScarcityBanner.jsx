// src/components/Tokenomics/ScarcityBanner.jsx
import React from "react";
import { motion } from "framer-motion";
import "./ScarcityBanner.css";

const ScarcityBanner = () => {
  return (
    <motion.div
      className="scarcity-banner"
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      viewport={{ once: true }}
    >
      <div className="scarcity-line">
        <span className="emoji">⛓️</span>
        <p>
          <strong>Mint-On-Demand:</strong> Supply is released gradually over 10 years, ensuring long-term scarcity.
        </p>
      </div>
      <div className="scarcity-line">
        <span className="emoji">🔒</span>
        <p>
          <strong>Team holds no tokens:</strong> 100% of supply is reserved for community, innovation, and growth.
        </p>
      </div>
    </motion.div>
  );
};

export default ScarcityBanner;
