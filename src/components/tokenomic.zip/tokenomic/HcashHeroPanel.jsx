// src/components/HcashHeroPanel.jsx
import React from "react";
import { motion } from "framer-motion";
import "./HcashHeroPanel.css";

const HcashHeroPanel = () => {
  return (
    <div className="hcash-hero-container">
      <motion.div
        className="hcash-core"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.2, ease: "easeOut" }}
      >
        <img
          src="/images/HCASH_CORE.png" // Usa aquí una imagen que simule un núcleo energético o reactor
          alt="Hcash Core"
          className="hcash-core-image"
        />
        <motion.div
          className="hcash-text"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 1 }}
        >
          <h1 className="hcash-title">Hunter Cash Token ($HCASH)</h1>
          <p className="hcash-subtitle">
            1,000,000,000 fixed supply over 10 years
          </p>
          <p className="hcash-tagline">
            <span className="highlight">Mint-On-Demand</span> – Scarce by design.
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default HcashHeroPanel;
