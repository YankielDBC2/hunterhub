// src/components/Tokenomics/TokenomicsSection.jsx
import React from "react";
import HcashHeroPanel from "./HcashHeroPanel";
import TokenDistributionChart from "./TokenDistributionChart";
import MiningTimeline from "./MiningTimeline";
import ScarcityBanner from "./ScarcityBanner";
import FloatingStatsCards from "./FloatingStatsCards";
import "./TokenomicsSection.css";

const TokenomicsSection = () => {
  return (
    <section className="tokenomics-section">
      <HcashHeroPanel />
      <FloatingStatsCards />
      <TokenDistributionChart />
      <MiningTimeline />
      <ScarcityBanner />
    </section>
  );
};

export default TokenomicsSection;
