// src/components/TokenDistributionChart.jsx
import React from "react";
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from "recharts";
import "./TokenDistributionChart.css";

const data = [
  { name: "Player Incentives", value: 70, icon: "🎮" },
  { name: "Innovation", value: 15, icon: "💡" },
  { name: "Marketing", value: 6.5, icon: "📣" },
  { name: "Partners & Investors", value: 5, icon: "🤝" },
  { name: "Liquidity", value: 3.5, icon: "💧" },
];

const COLORS = ["#00f2ff", "#04ff9f", "#ffcc00", "#ff6a00", "#ff004c"];

const CustomTooltip = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const { name, value } = payload[0].payload;
    return (
      <div className="tooltip-content">
        <strong>{name}</strong>
        <div>{value}% allocated</div>
      </div>
    );
  }
  return null;
};

const TokenDistributionChart = () => {
  return (
    <div className="token-chart-container">
      <h2 className="token-chart-title">Supply Distribution</h2>
      <ResponsiveContainer width="100%" height={400}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={80}
            outerRadius={130}
            paddingAngle={3}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip />} />
          <Legend
            formatter={(value, entry, index) => `${data[index].icon} ${value}`}
            iconType="circle"
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default TokenDistributionChart;
