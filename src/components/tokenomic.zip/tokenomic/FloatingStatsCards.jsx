// src/components/Tokenomics/FloatingStatsCards.jsx
import React from "react";
import Tilt from "react-parallax-tilt";
import "./FloatingStatsCards.css";

const stats = [
  {
    icon: "🪙",
    title: "Max Supply",
    value: "1,000,000,000",
    subtitle: "Fixed over 10 years",
  },
  {
    icon: "🚀",
    title: "Circulating",
    value: "<1,000,000",
    subtitle: "Currently in hands of players",
  },
  {
    icon: "⚡",
    title: "Annual Cap",
    value: "9%",
    subtitle: "Year 1 mining limit",
  },
];

const FloatingStatsCards = () => {
  return (
    <div className="stats-card-grid">
      {stats.map((stat, index) => (
        <Tilt tiltMaxAngleX={10} tiltMaxAngleY={10} glareEnable={true} glareColor="#00f2ff" key={index}>
          <div className="stats-card">
            <div className="card-icon">{stat.icon}</div>
            <h3 className="card-title">{stat.title}</h3>
            <p className="card-value">{stat.value}</p>
            <p className="card-subtitle">{stat.subtitle}</p>
          </div>
        </Tilt>
      ))}
    </div>
  );
};

export default FloatingStatsCards;
